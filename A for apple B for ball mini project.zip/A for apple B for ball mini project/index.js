var numberOfDrumButtons = document.querySelectorAll(".drum").length;

for (var i = 0; i < numberOfDrumButtons; i++) {

  document.querySelectorAll(".drum")[i].addEventListener("click", function() {

    var buttonInnerHTML = this.innerHTML;

    makeSound(buttonInnerHTML);

    buttonAnimation(buttonInnerHTML);

  });

}

document.addEventListener("keypress", function(event) {

  makeSound(event.key);

  buttonAnimation(event.key);

});


function makeSound(key) {

  switch (key) {
    case "A":
      var tom1 = new Audio("sounds/A.mp3");
      tom1.play();
      break;
    case "B":
      var tom1 = new Audio("sounds/b.mp3");
      tom1.play();
      break;
    case "C":
      var tom1 = new Audio("sounds/c.mp3");
      tom1.play();
      break;
    case "D":
      var tom1 = new Audio("sounds/d.mp3");
      tom1.play();
      break;
    case "E":
      var tom1 = new Audio("sounds/e.mp3");
      tom1.play();
      break;
    case "F":
      var tom1 = new Audio("sounds/f.mp3");
      tom1.play();
      break;
    case "G":
      var tom1 = new Audio("sounds/g.mp3");
      tom1.play();
      break;
    case "H":
      var tom1 = new Audio("sounds/h.mp3");
      tom1.play();
      break;
    case "I":
      var tom1 = new Audio("sounds/i.mp3");
      tom1.play();
      break;
    case "J":
      var tom1 = new Audio("sounds/j.mp3");
      tom1.play();
      break;
    case "K":
      var tom1 = new Audio("sounds/k.mp3");
      tom1.play();
      break;
    case "L":
      var tom1 = new Audio("sounds/l.mp3");
      tom1.play();
      break;
    case "M":
      var tom1 = new Audio("sounds/m.mp3");
      tom1.play();
      break;
    case "N":
      var tom1 = new Audio("sounds/n.mp3");
      tom1.play();
      break;
    case "O":
      var tom1 = new Audio("sounds/o.mp3");
      tom1.play();
      break;
    case "P":
      var tom1 = new Audio("sounds/p.mp3");
      tom1.play();
      break;
    case "Q":
      var tom1 = new Audio("sounds/q.mp3");
      tom1.play();
      break;
    case "R":
      var tom1 = new Audio("sounds/r.mp3");
      tom1.play();
      break;
    case "S":
      var tom1 = new Audio("sounds/s.mp3");
      tom1.play();
      break;
    case "T":
      var tom1 = new Audio("sounds/t.mp3");
      tom1.play();
      break;
    case "U":
      var tom1 = new Audio("sounds/u.mp3");
      tom1.play();
      break;
    case "V":
      var tom1 = new Audio("sounds/v.mp3");
      tom1.play();
      break;
    case "W":
      var tom1 = new Audio("sounds/w.mp3");
      tom1.play();
      break;
    case "X":
      var tom1 = new Audio("sounds/x.mp3");
      tom1.play();
      break;
    case "Y":
      var tom1 = new Audio("sounds/y.mp3");
      tom1.play();
      break;
    case "Z":
      var tom1 = new Audio("sounds/z.mp3");
      tom1.play();
      break;


    default: console.log(key);

  }
}


function buttonAnimation(currentKey) {

  var activeButton = document.querySelector("." + currentKey);

  activeButton.classList.add("pressed");

  setTimeout(function() {
    activeButton.classList.remove("pressed");
  }, 100);

}
