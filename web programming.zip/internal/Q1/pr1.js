function cal(){
    op = document.getElementById("operator").value;
    if (op=="+") {
        addBy()
    }
    
    else if (op=="-") {
        substractBy()
    }
     else if (op=="*") {
        multiplyBy()
    }
     else if (op=="/") {
        divideBy()
    }
    else
    {   msg="Please enter correct operator!!!!!"
        document.getElementById("result").innerHTML =msg;
    }
}
function addBy()
{
        num1 = document.getElementById("firstNumber").value;
        num2 = document.getElementById("secondNumber").value;
        document.getElementById("result").innerHTML = parseInt(num1) + parseInt(num2);
}

function substractBy()
{
        num1 = document.getElementById("firstNumber").value;
        num2 = document.getElementById("secondNumber").value;
        document.getElementById("result").innerHTML = num1 - num2;
}

function multiplyBy()
{
        num1 = document.getElementById("firstNumber").value;
        num2 = document.getElementById("secondNumber").value;
        document.getElementById("result").innerHTML = num1 * num2;
}

function divideBy() 
{ 
        num1 = document.getElementById("firstNumber").value;
        num2 = document.getElementById("secondNumber").value;
document.getElementById("result").innerHTML = num1 / num2;
}