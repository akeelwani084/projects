










<html>
<head>
    <style>
        .seat {
    margin-left: 45%;
    margin-top:15%;
            }
    </style>
</head>

<body>
    <form class="seat" method="POST">
        
        <input id="s1" type="submit" name="s1" value="s1"><br><br>
        <input id="s2" type="submit" name="s2" value="s2"><br><br>
        <input id="s3" type="submit" name="s3" value="s3"><br><br>
        <input id="s4" type="submit" name="s4" value="s4"><br><br>
        <input id="s5" type="submit" name="s5" value="s5"><br><br>
        <input id="s6" type="submit" name="s6" value="s6"><br><br>
        <input id="s7" type="submit" name="s7" value="s7"><br><br>
        <input id="s8"  type="submit" name="s8" value="s8"><br><br>
        <input id="s9" type="submit" name="s9" value="s9"><br><br>
        <input id="s10" type="submit" name="s10" value="s10"><br><br>
    </form>
</body>

</html>