<!DOCTYPE HTML>  
<html>
<head>
    <style>
        .error {color: #FF0000;
        margin-left: 800px;}
form
{
 background-color: lightblue;
 box-sizing: border-box;
 margin: 70px;
 border: 3px solid black; 
 margin-left: 300px;
 margin-right: 300px;
 padding: 30px;
}
h2 {
  color: brown;
  margin-left: 800px;
}
label{
    font-size: 20px;
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
}
div{
border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;}
select {
    width: 40%;
    padding: 16px 20px;
    border: none;
    border-radius: 4px;
    background-color: #f1f1f1;
  }
input   {
    width: 40%;
    padding: 5px ;
    margin: 5px;
   border: 2px solid skyblue;
   border-radius: 4px;
   box-sizing: border-box;
   font-size: 20px;
}
 input[type=submit] {
    background-color: #04AA6D;
    border: none;
    color: white;
    padding:  16px;
    text-decoration: none;
    margin:  2px;
    cursor: pointer;
    width: 200px;
  }


</style>

</head>

<body>  

    <?php

        $nameErr = $emailErr = $genderErr = $websiteErr = "";

        $name = $email = $gender = $comment = $website = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

        if (empty($_POST["name"])) {

            $nameErr = "Please enter a valid name";

        } else {

            $name = test_input($_POST["name"]);

            // check if name only contains letters and whitespace

            if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {

            $nameErr = "Only letters and white space allowed";

            }

        }

        if (empty($_POST["email"])) {

            $emailErr = "valid Email address";

        } else {

            $email = test_input($_POST["email"]);

            // check if e-mail address is well-formed

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            $emailErr = "The email address is incorrect";

            }

        }  

        if (empty($_POST["website"])) {

            $website = "";

        } else {

            $website = test_input($_POST["website"]);

            // check if URL address syntax is valid

            if (!preg_match("[1234567890]",$website)) {

            $websiteErr = "Enter a valid Webiste URL";

            }    

        }

        if (empty($_POST["comment"])) {

            $comment = "";

        } else {

            $comment = test_input($_POST["comment"]);

        }        

        if (empty($_POST["gender"])) {

            $genderErr = "Please select a gender";

        } else {

            $gender = test_input($_POST["gender"]);

        }

        }

        function test_input($data) {

        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;

        }

    ?>

    <h2>cesa registeration </h2>

    <p><span class="error">* required field</span></p>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  

        FullName: <input type="text" name="name" require="require">

        <span class="error">* <?php echo $nameErr;?></span>

        <br><br>

        E-mail address: <input type="text" name="email" require="require">

        <span class="error">* <?php echo $emailErr;?></span>

        <br><br>

        Contact No: <input type="text" name="website" require="require">

        <span class="error"><?php echo $websiteErr;?></span>

        <br><br>

        Postion: <textarea name="comment" rows="4" cols="10" require="require"></textarea>

        <br><br>

        Gender:

        <input type="radio" name="gender" value="female">Female

        <input type="radio" name="gender" value="male">Male

            <span class="error">* <?php echo $genderErr;?></span>

        <br><br>

        <input type="submit" name="submit" value="Submit">  

    </form>

    <?php

        echo "<h2> Final Output:</h2>";

        echo $name;

        echo "<br>";

        echo $email;

        echo "<br>";

        echo $website;

        echo "<br>";

        echo $comment;

        echo "<br>";

        echo $gender;

    ?>

</body>

</html>