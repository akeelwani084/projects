<?php
include "db.php";
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $dep = $_POST['dep'];
    $cls = $_POST['class'];
    $pass = $_POST['inter'];
    $s = "INSERT INTO `internship`(`name`, `dep`, `class`, `inter`) VALUES ('$name','$dep','$cls','$pass')";
    $result = $con->query($s);
    if($result == TRUE)
    {
        echo "<script type='text/javascript'> alert('Uploaded Successfully');";
        echo 'window.location = "upload.php";';
        echo '</script>';
    }
    else{
        echo "<script type='text/javascript'> alert('Error.......'); </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>upload info </title>
</head>
<body>
    <form action="" method="POST">
    <label>Name :</label><input type="text" name="name" ><br><br>
    <label>Department :</label><input type="text" name="dep" /><br><br>
    <label>Class :</label><input type="text" name="class" /><br><br>
    <label>Internship in :</label><input type="text" name="inter" /><br><br>
    <input type="submit" name="submit" value="Upload">
    </form>
</body>
</html>