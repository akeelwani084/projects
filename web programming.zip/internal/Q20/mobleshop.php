<!DOCTYPE html>
<html lang="en">
<head>
    <title>MOBILE SHOP</title>
</head>
<style>
    body{
        background-color:pink;
    }
    h1{
        margin-left: 800px;
    }
    div{
        width: 600px;
        background-color:aqua;
        margin-left: 700px;
    }
    img{
        margin-left: 50px;
    }
    h3,h5,input{
        margin-left: 250px;
    }
</style>
<body>
    <h1>WEB MOBILE SHOP</h1>
<form action="" method="post">
<div>
					<img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60">
                    <h3>iphone</h3>
				    <h5>Starting from 26,000</h5>
                    <input type="submit" value="shop now" name="s1">
				</div>
                <div>
					<img src="https://images.unsplash.com/photo-1557189750-56d1be9e963a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" >
                    <h3>SONY</h3>
					<h5>Starting from 23,500</h5>
                    <input type="submit" value="shop now" name="s3">
				</div>
                <div>
					<img src="https://images.unsplash.com/photo-1549846130-54aa06586995?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" >
					<h3>Realme</h3>
					<h5>Starting from 15,200</h5>
                    <input type="submit" value="shop now" name="s4">
				</div>
                <div>
					<img src="https://images.unsplash.com/photo-1575571536958-38aa1227786a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" >
					<h3>samsung</h3>
					<h5>Starting from 32,000</h5>
                    <input type="submit" value="shop now" name="s5">
				</div>
</form>
</body>
</html>
<?php

if(isset($_POST['s1']))
{
}
if(isset($_POST['s2']))
{
}
if(isset($_POST['s3']))
{
}
if(isset($_POST['s4']))
{
}
?>
