<!DOCTYPE html>
<html lang="en">

<head>
    <title>log in </title>
    <style>
    input[type=text], input[type=password] {   
        width: 10%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid black;   
        box-sizing: border-box;   
    }
    Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
} 
form{
    margin-top: 200px;
    padding: 25px;   
}
    </style>
</head>

<body><center>
    <form action="" method="POST">
        <label>Username : </label>
        <input type="text" placeholder="Enter Username" name="username" required><br><br>
        <label>Password : </label>
        <input type="password" placeholder="Enter Password" name="password" required><br><br>
        <input type="submit" name="login" value="Log in"></input>
    </form>
    </center>
</body>

</html>

<?php
if(isset($_POST['login'])){
    $usr = array("Rutuja", "Rutu", "Rutuja45");
    $pass = array("Rutu4545", "Rohit45", "4545");
    $u=$_POST['username'];
    $p=$_POST['password'];
    $ps=0;
    foreach ($usr as $ur) {
        if ($u==$ur) {
            break;
        }
        $ps=$ps+1;
      }
      
    if($p==$pass[$ps])
    {            
     echo '<script type ="text/javascript">';
     echo 'alert("Login Successfully");';
     echo'</script>';
    }
    else{
     echo "<script type='text/javascript'> alert('user not found or incorrect password ')</script>";
    }
}
?>